import { useAuth } from "@/App";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { PlusIcon } from "lucide-react";
import Sidebar from "@/components/dashboard/sidebar";
import UpcomingMeetings from "@/components/dashboard/upcoming-meetings";
import BookingLinks from "@/components/dashboard/booking-links";
import { useState, useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { getUserTimezone } from "@/lib/utils";
import { Meeting, MeetingType } from "@shared/schema";

export default function Dashboard() {
  const { user, isLoading: isAuthLoading } = useAuth();
  const [, navigate] = useLocation();
  const [timezone] = useState(getUserTimezone());

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthLoading && !user) {
      navigate("/login");
    }
  }, [user, isAuthLoading, navigate]);

  // Fetch meetings
  const {
    data: meetings,
    isLoading: isMeetingsLoading
  } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
    enabled: !!user,
  });

  // Fetch meeting types
  const {
    data: meetingTypes,
    isLoading: isMeetingTypesLoading
  } = useQuery<MeetingType[]>({
    queryKey: ["/api/meeting-types"],
    enabled: !!user,
  });

  // Show loading state
  if (isAuthLoading || isMeetingsLoading || isMeetingTypesLoading) {
    return (
      <div className="min-h-screen flex">
        <Sidebar />
        <div className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-10 w-40" />
          </div>
          
          <div className="mb-8">
            <Skeleton className="h-6 w-48 mb-4" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Skeleton className="h-32 rounded-lg" />
              <Skeleton className="h-32 rounded-lg" />
            </div>
          </div>
          
          <div>
            <Skeleton className="h-6 w-40 mb-4" />
            <div className="grid grid-cols-1 gap-4">
              <Skeleton className="h-16 rounded-lg" />
              <Skeleton className="h-16 rounded-lg" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-bold text-[#1C4A1C]">Dashboard</h1>
          <Button 
            className="bg-[#9ACD32] text-[#1C4A1C] hover:bg-[#D4E157]"
            onClick={() => navigate("/meetings/create")}
          >
            <PlusIcon className="mr-1 h-4 w-4" />
            Create Meeting
          </Button>
        </div>
        
        <UpcomingMeetings meetings={meetings || []} timezone={timezone} />
        
        <BookingLinks meetingTypes={meetingTypes || []} username={user?.username || ""} />
      </div>
    </div>
  );
}
