import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import HeroSection from "@/components/home/hero-section";
import FeaturesPreview from "@/components/home/features-preview";
import HowItWorks from "@/components/home/how-it-works";
import Testimonials from "@/components/home/testimonials";
import PricingSection from "@/components/home/pricing-section";
import CtaSection from "@/components/home/cta-section";
import { useRef, useEffect, useState } from "react";

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const featuresRef = useRef<HTMLDivElement>(null);
  const howItWorksRef = useRef<HTMLDivElement>(null);
  const testimonialsRef = useRef<HTMLDivElement>(null);
  const pricingRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  
  const [scrollY, setScrollY] = useState(0);
  
  // Scroll tracking for animation triggers
  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-grow flex flex-col">
        {/* Hero Section */}
        <div ref={heroRef} className="fade-in">
          <HeroSection />
        </div>
        
        {/* Feature Highlights */}
        <div 
          ref={featuresRef} 
          className="mx-4 sm:mx-8 md:mx-12 lg:mx-16 xl:mx-auto max-w-7xl bg-card shadow-lg rounded-2xl p-6 md:p-10 my-8 md:my-12 lg:my-16 slide-up"
        >
          <FeaturesPreview />
        </div>
        
        {/* How It Works Preview */}
        <div 
          ref={howItWorksRef} 
          id="how-it-works"
          className="py-12 md:py-16 slide-right delay-100"
        >
          <HowItWorks />
        </div>
        
        {/* Testimonials Section */}
        <div 
          ref={testimonialsRef} 
          className="mx-4 sm:mx-8 md:mx-12 lg:mx-16 xl:mx-auto max-w-7xl bg-card shadow-lg rounded-2xl p-6 md:p-10 my-8 md:my-12 lg:my-16 scale-in delay-300"
        >
          <Testimonials />
        </div>
        
        {/* Pricing Preview */}
        <div 
          ref={pricingRef} 
          className="py-12 md:py-16 slide-up delay-400"
        >
          <PricingSection />
        </div>
        
        {/* Final CTA Banner */}
        <div 
          ref={ctaRef} 
          className="bounce-in delay-500 my-8 md:my-12 lg:my-16"
        >
          <CtaSection />
        </div>
      </main>
      <Footer />
    </div>
  );
}
