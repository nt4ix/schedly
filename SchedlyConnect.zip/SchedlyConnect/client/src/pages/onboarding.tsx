import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/App";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import StepOne from "@/components/onboarding/step-one";
import StepTwo from "@/components/onboarding/step-two";
import StepThree from "@/components/onboarding/step-three";
import StepFour from "@/components/onboarding/step-four";
import { type OnboardingProgress } from "@shared/schema";

export default function Onboarding() {
  const { user, isLoading: isAuthLoading } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [, navigate] = useLocation();

  const { data: onboardingProgress, isLoading } = useQuery<OnboardingProgress>({
    queryKey: ["/api/onboarding"],
    enabled: !!user,
  });

  const updateOnboardingMutation = useMutation({
    mutationFn: async (data: Partial<OnboardingProgress>) => {
      const response = await apiRequest("PUT", "/api/onboarding", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/onboarding"] });
    },
  });

  // Set current step from server data when available
  useEffect(() => {
    if (onboardingProgress && !isLoading) {
      setCurrentStep(onboardingProgress.currentStep);
      
      // If onboarding is already completed, redirect to dashboard
      if (onboardingProgress.completed) {
        navigate("/dashboard");
      }
    }
  }, [onboardingProgress, isLoading, navigate]);

  // Handle step navigation
  const goToNextStep = async () => {
    const nextStep = currentStep + 1;
    setCurrentStep(nextStep);
    
    // Update onboarding progress in database
    updateOnboardingMutation.mutate({
      currentStep: nextStep,
    });
    
    // If this is the last step, mark onboarding as completed
    if (nextStep > 4) {
      updateOnboardingMutation.mutate({
        currentStep: 4,
        completed: true,
      });
      navigate("/dashboard");
    }
  };

  const goToPreviousStep = () => {
    const prevStep = Math.max(1, currentStep - 1);
    setCurrentStep(prevStep);
    
    // Update onboarding progress in database
    updateOnboardingMutation.mutate({
      currentStep: prevStep,
    });
  };

  const skipStep = () => {
    goToNextStep();
  };

  // Show loading state while fetching user and onboarding data
  if (isAuthLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
        <Card className="w-full max-w-4xl">
          <CardContent className="p-6">
            <div className="space-y-2 mb-8">
              <Skeleton className="h-8 w-3/4 mx-auto" />
              <Skeleton className="h-4 w-1/2 mx-auto" />
            </div>
            <div className="space-y-4">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
            <div className="flex justify-between mt-8">
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="container mx-auto max-w-4xl">
        <Card>
          <CardContent className="p-6 md:p-8">
            {/* Step indicators */}
            <div className="flex mb-8 justify-center">
              {[1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className={`
                    step-indicator w-10 h-10 rounded-full
                    flex items-center justify-center font-bold mr-3
                    transition-colors
                    ${
                      step === currentStep
                        ? "bg-[#1C4A1C] text-white"
                        : step < currentStep
                        ? "bg-[#9ACD32] text-[#1C4A1C]"
                        : "bg-white text-[#1C4A1C] border-2 border-[#1C4A1C]"
                    }
                  `}
                >
                  {step}
                </div>
              ))}
            </div>

            {/* Step content */}
            <div className="onboarding-step">
              {currentStep === 1 && (
                <StepOne 
                  onConnectCalendar={(provider) => {
                    // In a real app, handle OAuth flow here
                    updateOnboardingMutation.mutate({
                      calendarConnected: true
                    });
                    goToNextStep();
                  }}
                  onSkip={skipStep}
                />
              )}

              {currentStep === 2 && (
                <StepTwo
                  onNext={goToNextStep} 
                  onPrevious={goToPreviousStep}
                  onAvailabilitySet={() => {
                    updateOnboardingMutation.mutate({
                      availabilitySet: true
                    });
                  }}
                />
              )}

              {currentStep === 3 && (
                <StepThree
                  onNext={goToNextStep}
                  onPrevious={goToPreviousStep}
                />
              )}

              {currentStep === 4 && (
                <StepFour
                  onNext={goToNextStep}
                  onPrevious={goToPreviousStep}
                  onComplete={() => {
                    updateOnboardingMutation.mutate({
                      profileComplete: true,
                      completed: true
                    });
                  }}
                />
              )}
            </div>

            {/* Navigation */}
            <div className="flex justify-between mt-8">
              {currentStep > 1 && (
                <Button
                  variant="outline"
                  onClick={goToPreviousStep}
                  disabled={updateOnboardingMutation.isPending}
                >
                  Previous
                </Button>
              )}
              {currentStep === 1 && <div></div>}
              
              {currentStep < 4 ? (
                <Button
                  className="bg-[#1C4A1C] hover:bg-[#2C602C]"
                  onClick={goToNextStep}
                  disabled={updateOnboardingMutation.isPending}
                >
                  {updateOnboardingMutation.isPending ? "Saving..." : "Continue"}
                </Button>
              ) : (
                <Button
                  className="bg-[#1C4A1C] hover:bg-[#2C602C]"
                  onClick={goToNextStep}
                  disabled={updateOnboardingMutation.isPending}
                >
                  {updateOnboardingMutation.isPending ? "Completing..." : "Complete Setup"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
