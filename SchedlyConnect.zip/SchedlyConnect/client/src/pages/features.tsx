import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const features = [
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
        />
      </svg>
    ),
    title: "Timezone Sync",
    description:
      "Never calculate time differences again. Schedly automatically detects and displays meeting times in each participant's local timezone, eliminating confusion and missed meetings due to timezone miscalculations.",
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
        />
      </svg>
    ),
    title: "Group Scheduling",
    description:
      "Find the perfect meeting time for everyone without the back-and-forth emails. Share a single link that allows participants to indicate their availability, and Schedly will suggest optimal meeting times based on everyone's schedule.",
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
        />
      </svg>
    ),
    title: "Custom Booking Links",
    description:
      "Create personalized scheduling links for different meeting types. Set your availability, meeting duration, and buffer times, then share your custom link with anyone to let them book time on your calendar without the hassle.",
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
        />
      </svg>
    ),
    title: "Calendar Integration",
    description:
      "Seamlessly connect with Google Calendar, Outlook, or Apple Calendar. Schedly checks your existing calendar for conflicts and only shows available times, ensuring no double bookings or scheduling errors.",
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
        />
      </svg>
    ),
    title: "Smart Notifications",
    description:
      "Automated reminders and notifications for you and your invitees. Reduce no-shows with customizable email or calendar notifications sent at your preferred timing before meetings.",
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
        />
      </svg>
    ),
    title: "Privacy Control",
    description:
      "Control what information is shared with your meeting attendees. Keep certain calendar details private while still enabling efficient scheduling without exposing sensitive information.",
  },
];

export default function Features() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Hero */}
        <section className="bg-[#1C4A1C] py-16 md:py-20">
          <div className="container mx-auto px-6 md:px-10 lg:px-16 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-[#D4E157] mb-6">
              Powerful Features for Seamless Scheduling
            </h1>
            <p className="text-xl text-white max-w-3xl mx-auto mb-8">
              Discover how Schedly's innovative features eliminate scheduling
              headaches and save you valuable time.
            </p>
            <Link href="/signup">
              <Button className="bg-[#9ACD32] text-[#1C4A1C] font-bold px-8 py-3 rounded-md text-lg hover:bg-[#D4E157] transition-colors">
                Start Free Trial
              </Button>
            </Link>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6 md:px-10 lg:px-16">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {features.map((feature, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-all">
                  <div className="w-16 h-16 bg-[#1C4A1C] rounded-full flex items-center justify-center mb-6 text-white">
                    {feature.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-[#1C4A1C] mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-700">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Integration */}
        <section className="py-20 bg-gray-100">
          <div className="container mx-auto px-6 md:px-10 lg:px-16">
            <div className="flex flex-col lg:flex-row items-center">
              <div className="lg:w-1/2 mb-10 lg:mb-0 lg:pr-16">
                <h2 className="text-3xl md:text-4xl font-bold text-[#1C4A1C] mb-6">
                  Seamless Integrations With Your Favorite Tools
                </h2>
                <p className="text-lg text-gray-700 mb-6">
                  Schedly integrates with the tools you already use, making it easy to
                  incorporate into your existing workflow without disruption.
                </p>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-start">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-[#43A047] mr-2 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    <span className="text-gray-700">
                      Sync with Google Calendar, Outlook, and Apple Calendar
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-[#43A047] mr-2 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    <span className="text-gray-700">
                      Connect with Zoom, Google Meet, and Microsoft Teams
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-[#43A047] mr-2 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    <span className="text-gray-700">
                      Webhook support for custom integrations
                    </span>
                  </li>
                  <li className="flex items-start">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-[#43A047] mr-2 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    <span className="text-gray-700">
                      API access for developers (Pro & Team plans)
                    </span>
                  </li>
                </ul>
                <Link href="/pricing">
                  <Button className="bg-[#1C4A1C] text-white px-6 py-3 rounded-md hover:bg-[#2C602C] transition-colors">
                    View Pricing Plans
                  </Button>
                </Link>
              </div>
              <div className="lg:w-1/2">
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                    <div className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
                      <svg className="h-12 w-12 text-[#DB4437]" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z"/>
                      </svg>
                    </div>
                    <div className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
                      <svg className="h-12 w-12 text-[#0072C6]" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M0 0v11.408h11.408V0H0zm12.594 0v11.408H24V0H12.594zM0 12.594V24h11.408V12.594H0zm12.594 0V24H24V12.594H12.594z"/>
                      </svg>
                    </div>
                    <div className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
                      <svg className="h-12 w-12 text-gray-800" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M22.0617 17.4634C21.6202 18.5517 21.0451 19.452 20.3364 20.1611C19.3909 21.1342 18.3174 21.6559 17.1183 21.7262C16.3375 21.7789 15.538 21.5681 14.7208 21.094C13.9037 20.6199 13.1667 20.3828 12.5097 20.3828C11.8165 20.3828 11.0619 20.6199 10.2447 21.094C9.4275 21.5681 8.69349 21.7964 8.04258 21.7964C6.90206 21.8315 5.82129 21.2924 4.80021 20.2839C4.05087 19.5395 3.44226 18.5869 2.9744 17.4283C2.47626 16.1815 2.22656 14.982 2.22656 13.8235C2.22656 12.4934 2.56501 11.365 3.23957 10.4385C3.76513 9.71243 4.44905 9.14834 5.29132 8.74626C6.13359 8.34418 7.04559 8.13159 8.0256 8.11403C8.84225 8.11403 9.87631 8.39429 11.138 8.94838C12.3997 9.51027 13.1842 9.78273 13.4916 9.78273C13.7282 9.78273 14.6402 9.45359 16.2414 8.7973C17.7372 8.19308 19.0046 7.94769 20.0555 8.05842C22.1557 8.29601 23.7569 9.24031 24.8466 10.892C23.0058 11.9452 22.0942 13.4194 22.1119 15.314C22.1295 16.769 22.6453 17.9803 23.6586 18.9358C23.1774 19.4722 22.6453 19.9412 22.0617 20.335C22.753 19.3969 23.0235 18.3005 22.8884 17.0888C22.8024 17.2172 22.4551 17.3543 22.0617 17.4634ZM17.1359 0C17.1535 0.1107 17.1711 0.21361 17.1711 0.31651C17.1711 1.56259 16.7358 2.76913 15.8674 3.92613C14.8805 5.24622 13.5956 5.99548 12.1526 5.88475C12.1349 5.76622 12.1261 5.63989 12.1261 5.50577C12.1261 4.30703 12.6177 3.02938 13.4916 1.92203C13.927 1.3601 14.476 0.889844 15.1329 0.511244C15.7886 0.141432 16.4631 -0.0359266 17.1359 0Z" />
                      </svg>
                    </div>
                    <div className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
                      <svg className="h-12 w-12 text-[#2D8CFF]" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M24 11.9999C24 5.37491 18.6251 0 12 0C5.37494 0 0 5.37491 0 11.9999C0 18.6251 5.37494 23.9999 12 23.9999C18.6251 23.9999 24 18.6251 24 11.9999Z" />
                        <path fill="white" d="M10.75 16.2068L17.4 11.9997L10.75 7.79224V16.2068Z" />
                        <path fill="white" d="M6.59998 16.2068L13.25 11.9997L6.59998 7.79224V16.2068Z" />
                      </svg>
                    </div>
                    <div className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
                      <svg className="h-12 w-12 text-[#464EB8]" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M17.785 13.9935L22.5 10.0004V20.0004H15V15.0004C15 14.4485 15.448 14.0004 16 14.0004C16.552 14.0004 17 14.4485 17 15.0004C17 15.0104 17 15.0204 16.999 15.0304C16.975 16.1204 17.478 17.1195 18.362 17.7095L17.785 13.9935Z" />
                        <path d="M12.5 2.00195C13.163 2.00195 14.01 2.22195 14.549 2.32895C15.059 2.42895 15.529 2.59595 15.979 2.81395C16.429 3.03295 16.84 3.31595 17.22 3.64895C17.578 3.96195 17.889 4.31695 18.17 4.69095L18.369 4.97395C18.84 5.63495 19.19 6.37495 19.399 7.15695C19.58 7.84895 19.67 8.25695 19.76 8.87695C19.85 9.48895 19.92 10.0609 19.98 10.8239L15 14.6929C14.929 15.6519 14.94 16.5229 14.94 17.0009H9.06C9.06 16.5229 9.07 15.6519 9 14.6929L4.02 10.8239C4.08 10.0609 4.15 9.48795 4.24 8.87695C4.33 8.25795 4.42 7.84895 4.6 7.15695C4.81 6.37495 5.16 5.63495 5.631 4.97395L5.83 4.69095C6.111 4.31695 6.421 3.96195 6.78 3.64895C7.16 3.31595 7.57 3.03295 8.02 2.81395C8.47 2.59595 8.94 2.42895 9.45 2.32895C9.989 2.22195 10.837 2.00195 11.5 2.00195H12.5Z" />
                        <path d="M9 14.6924V20.0004H1.5V10.0004L6.215 13.9934L5.638 17.7094C6.522 17.1194 7.025 16.1204 7.001 15.0304C7 15.0204 7 15.0104 7 15.0004C7 14.4484 7.448 14.0004 8 14.0004C8.552 14.0004 9 14.4484 9 15.0004V14.6924Z" />
                      </svg>
                    </div>
                    <div className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
                      <svg className="h-12 w-12 text-[#343434]" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 0C5.373 0 0 5.373 0 12C0 18.627 5.373 24 12 24C18.627 24 24 18.627 24 12C24 5.373 18.627 0 12 0ZM4.2 19.8C5.6868 21 7.5144 21.6 9.6 21.6C14.4 21.6 18 18 18 13.2C18 10.8 16.8 8.4 15 6.6C15 9 13.8 12 12 14.4C9.6 18 7.2 19.8 4.2 19.8ZM19.8 18C21 16.5132 21.6 14.6856 21.6 12.6C21.6 7.8 18 4.2 13.2 4.2C10.8 4.2 8.4 5.4 6.6 7.2C9 7.2 12 8.4 14.4 10.2C18 12.6 19.8 15 19.8 18Z" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-[#1C4A1C] text-white">
          <div className="container mx-auto px-6 md:px-10 lg:px-16 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Transform Your Scheduling Experience?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Join thousands of professionals who have streamlined their scheduling
              process with Schedly.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/signup">
                <Button className="bg-[#9ACD32] text-[#1C4A1C] font-bold px-8 py-4 rounded-md text-lg hover:bg-[#D4E157] transition-colors w-full sm:w-auto">
                  Start Your Free Trial
                </Button>
              </Link>
              <Link href="/pricing">
                <Button variant="outline" className="border-white text-white px-8 py-4 rounded-md text-lg hover:bg-white hover:bg-opacity-10 transition-colors w-full sm:w-auto">
                  View Pricing Plans
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
