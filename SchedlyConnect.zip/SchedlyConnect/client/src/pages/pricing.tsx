import { useState } from "react";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CheckIcon } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const pricingPlans = [
  {
    name: "Free",
    price: "0",
    description: "Perfect for individuals just getting started",
    features: [
      "1 calendar connection",
      "Basic scheduling",
      "Standard meeting types",
      "Schedly branding",
      "Email notifications",
      "Unlimited meetings"
    ],
    buttonText: "Get Started",
    buttonLink: "/signup",
    highlighted: false
  },
  {
    name: "Pro",
    price: "12",
    description: "For professionals and small teams",
    features: [
      "Unlimited calendar connections",
      "Advanced scheduling options",
      "Custom branding",
      "Group meeting coordination",
      "Email reminders & notifications",
      "Buffer times between meetings",
      "Custom meeting durations",
      "Meeting polls",
      "Priority support"
    ],
    buttonText: "Start Pro Trial",
    buttonLink: "/signup",
    highlighted: true,
    badge: "Most Popular"
  },
  {
    name: "Team",
    price: "30",
    priceDetail: "/user/month",
    description: "For teams and organizations",
    features: [
      "Everything in Pro, plus:",
      "Team dashboard",
      "Shared availability",
      "Admin controls",
      "Priority support",
      "SSO & advanced security",
      "User provisioning",
      "Analytics & reporting",
      "Dedicated account manager",
      "Custom integrations"
    ],
    buttonText: "Contact Sales",
    buttonLink: "#contact-sales",
    highlighted: false
  }
];

const faqs = [
  {
    question: "How does the free trial work?",
    answer: "Schedly offers a 7-day free trial of our Pro plan with full access to all features. No credit card is required to start your trial. At the end of your trial, you can choose to upgrade to a paid plan or continue with our Free plan."
  },
  {
    question: "Can I change plans later?",
    answer: "Yes, you can upgrade, downgrade, or cancel your plan at any time. When upgrading, the new plan and features become available immediately. If you downgrade, you'll continue to have access to your current plan until the end of your billing cycle."
  },
  {
    question: "Is there a limit to how many meetings I can schedule?",
    answer: "No, all Schedly plans include unlimited meetings. The differences between plans are related to features, integrations, and customization options, not usage limits."
  },
  {
    question: "How do team accounts work?",
    answer: "Team accounts allow multiple users to share a single Schedly account with centralized billing and administration. Administrators can manage user permissions, view team-wide scheduling analytics, and configure shared settings."
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all major credit cards including Visa, Mastercard, American Express, and Discover. For Team plans with annual billing, we also offer invoicing and bank transfers."
  },
  {
    question: "Do you offer discounts for non-profits or educational institutions?",
    answer: "Yes, we offer special pricing for qualified non-profit organizations, educational institutions, and students. Please contact our sales team for more information."
  },
]

export default function Pricing() {
  const [isMonthly, setIsMonthly] = useState(true);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Hero */}
        <section className="bg-[#1C4A1C] py-16 md:py-20">
          <div className="container mx-auto px-6 md:px-10 lg:px-16 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-[#D4E157] mb-6">
              Simple, Transparent Pricing
            </h1>
            <p className="text-xl text-white max-w-3xl mx-auto mb-8">
              Choose the plan that fits your scheduling needs. All plans include our core 
              scheduling features with no hidden fees.
            </p>
          </div>
        </section>

        {/* Pricing */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-6 md:px-10 lg:px-16">
            <div className="flex justify-center mb-8">
              <div className="bg-gray-100 rounded-full p-1 inline-flex">
                <button 
                  className={`px-6 py-2 rounded-full ${
                    isMonthly 
                      ? "bg-[#9ACD32] text-[#1C4A1C] font-semibold" 
                      : "text-neutral-dark"
                  }`}
                  onClick={() => setIsMonthly(true)}
                >
                  Monthly
                </button>
                <button 
                  className={`px-6 py-2 rounded-full ${
                    !isMonthly 
                      ? "bg-[#9ACD32] text-[#1C4A1C] font-semibold" 
                      : "text-neutral-dark"
                  }`}
                  onClick={() => setIsMonthly(false)}
                >
                  Annually (20% off)
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {pricingPlans.map((plan, index) => (
                <div 
                  key={index} 
                  className={`
                    relative
                    bg-white rounded-xl overflow-hidden shadow-md 
                    ${plan.highlighted 
                      ? "border-2 border-[#9ACD32] transform md:-translate-y-4" 
                      : "border border-gray-100"
                    }
                  `}
                >
                  {plan.badge && (
                    <div className="bg-[#9ACD32] text-[#1C4A1C] text-center py-2 font-semibold">
                      {plan.badge}
                    </div>
                  )}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-[#1C4A1C] mb-2">{plan.name}</h3>
                    <div className="mb-4">
                      <span className="text-3xl font-bold text-[#1C4A1C]">
                        ${isMonthly ? plan.price : (Number(plan.price) * 0.8).toFixed()}
                      </span>
                      <span className="text-neutral-dark">{plan.priceDetail || "/month"}</span>
                    </div>
                    <p className="text-neutral-dark mb-6">{plan.description}</p>
                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start">
                          <CheckIcon className="h-5 w-5 text-[#43A047] mt-0.5 mr-2" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Link href={plan.buttonLink}>
                      <Button 
                        className={`block w-full py-3 rounded-md font-semibold text-center transition-colors ${
                          plan.highlighted
                            ? "bg-[#1C4A1C] text-white hover:bg-[#2C602C]"
                            : "bg-gray-100 text-[#1C4A1C] hover:bg-gray-200"
                        }`}
                      >
                        {plan.buttonText}
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-12 text-center text-gray-600 max-w-xl mx-auto">
              <p>All plans include our core scheduling features, timezone detection, 
                email notifications, and basic calendar integrations. Prices shown in USD.</p>
            </div>
          </div>
        </section>

        {/* Compare */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-6 md:px-10 lg:px-16">
            <h2 className="text-3xl font-bold text-[#1C4A1C] text-center mb-12">
              Compare All Features
            </h2>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="px-4 py-3 text-left w-1/3">Feature</th>
                    <th className="px-4 py-3 text-center">Free</th>
                    <th className="px-4 py-3 text-center">Pro</th>
                    <th className="px-4 py-3 text-center">Team</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Calendar Connections</td>
                    <td className="px-4 py-3 text-center">1</td>
                    <td className="px-4 py-3 text-center">Unlimited</td>
                    <td className="px-4 py-3 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Meeting Types</td>
                    <td className="px-4 py-3 text-center">3</td>
                    <td className="px-4 py-3 text-center">Unlimited</td>
                    <td className="px-4 py-3 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Group Meetings</td>
                    <td className="px-4 py-3 text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-red-500 mx-auto"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <CheckIcon className="h-5 w-5 text-[#43A047] mx-auto" />
                    </td>
                    <td className="px-4 py-3 text-center">
                      <CheckIcon className="h-5 w-5 text-[#43A047] mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Custom Branding</td>
                    <td className="px-4 py-3 text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-red-500 mx-auto"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <CheckIcon className="h-5 w-5 text-[#43A047] mx-auto" />
                    </td>
                    <td className="px-4 py-3 text-center">
                      <CheckIcon className="h-5 w-5 text-[#43A047] mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Team Management</td>
                    <td className="px-4 py-3 text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-red-500 mx-auto"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-red-500 mx-auto"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <CheckIcon className="h-5 w-5 text-[#43A047] mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Admin Controls</td>
                    <td className="px-4 py-3 text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-red-500 mx-auto"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-red-500 mx-auto"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <CheckIcon className="h-5 w-5 text-[#43A047] mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Analytics & Reporting</td>
                    <td className="px-4 py-3 text-center">Basic</td>
                    <td className="px-4 py-3 text-center">Enhanced</td>
                    <td className="px-4 py-3 text-center">Advanced</td>
                  </tr>
                  <tr className="border-b border-gray-200">
                    <td className="px-4 py-3 font-medium">Support</td>
                    <td className="px-4 py-3 text-center">Email</td>
                    <td className="px-4 py-3 text-center">Priority</td>
                    <td className="px-4 py-3 text-center">Priority + Dedicated</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* FAQs */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-6 md:px-10 lg:px-16 max-w-4xl">
            <h2 className="text-3xl font-bold text-[#1C4A1C] text-center mb-12">
              Frequently Asked Questions
            </h2>
            
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left text-lg font-medium">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-700">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            
            <div className="mt-12 text-center">
              <p className="text-gray-700 mb-6">Still have questions?</p>
              <Button className="bg-[#1C4A1C] text-white hover:bg-[#2C602C]">
                Contact Sales
              </Button>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-[#1C4A1C] text-white">
          <div className="container mx-auto px-6 md:px-10 lg:px-16 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Transform Your Scheduling Experience?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Join thousands of professionals who have streamlined their scheduling
              process with Schedly.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/signup">
                <Button className="bg-[#9ACD32] text-[#1C4A1C] font-bold px-8 py-4 rounded-md text-lg hover:bg-[#D4E157] transition-colors w-full sm:w-auto">
                  Start Your Free Trial
                </Button>
              </Link>
              <Button variant="outline" className="border-white text-white px-8 py-4 rounded-md text-lg hover:bg-white hover:bg-opacity-10 transition-colors w-full sm:w-auto">
                Contact Sales
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
