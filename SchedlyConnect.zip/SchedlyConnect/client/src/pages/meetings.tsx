import { useState, useEffect } from "react";
import { useAuth } from "@/App";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import Sidebar from "@/components/dashboard/sidebar";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Clock, Plus, Trash, Users, Video } from "lucide-react";
import { Meeting, MeetingType } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { formatDate, formatTime } from "@/lib/utils";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import CreateMeetingForm from "@/components/meetings/create-meeting-form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Meetings() {
  const { user, isLoading: isAuthLoading } = useAuth();
  const [, navigate] = useLocation();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [deletingMeetingId, setDeletingMeetingId] = useState<number | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthLoading && !user) {
      navigate("/login");
    }
  }, [user, isAuthLoading, navigate]);

  // Fetch meetings
  const {
    data: meetings,
    isLoading: isMeetingsLoading
  } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
    enabled: !!user,
  });

  // Fetch meeting types
  const {
    data: meetingTypes,
    isLoading: isMeetingTypesLoading
  } = useQuery<MeetingType[]>({
    queryKey: ["/api/meeting-types"],
    enabled: !!user,
  });

  // Delete meeting mutation
  const deleteMeetingMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/meetings/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      setDeletingMeetingId(null);
    }
  });

  // Show loading state
  if (isAuthLoading || isMeetingsLoading || isMeetingTypesLoading) {
    return (
      <div className="min-h-screen flex">
        <Sidebar />
        <div className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-10 w-40" />
          </div>
          
          <div className="mb-4">
            <Skeleton className="h-10 w-64" />
          </div>
          
          <div className="space-y-4">
            <Skeleton className="h-24 rounded-lg" />
            <Skeleton className="h-24 rounded-lg" />
            <Skeleton className="h-24 rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  // Filter meetings by upcoming or past
  const now = new Date();
  const upcomingMeetings = meetings?.filter(m => new Date(m.startTime) > now) || [];
  const pastMeetings = meetings?.filter(m => new Date(m.startTime) <= now) || [];

  return (
    <div className="min-h-screen flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-bold text-[#1C4A1C]">Meetings</h1>
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#9ACD32] text-[#1C4A1C] hover:bg-[#D4E157]">
                <Plus className="mr-1 h-4 w-4" />
                Create Meeting
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Create New Meeting</DialogTitle>
              </DialogHeader>
              <CreateMeetingForm 
                meetingTypes={meetingTypes || []} 
                onSuccess={() => {
                  setCreateDialogOpen(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="upcoming">
              Upcoming ({upcomingMeetings.length})
            </TabsTrigger>
            <TabsTrigger value="past">
              Past ({pastMeetings.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming">
            {upcomingMeetings.length > 0 ? (
              <div className="space-y-4">
                {upcomingMeetings.map((meeting) => (
                  <MeetingCard 
                    key={meeting.id} 
                    meeting={meeting} 
                    onDelete={() => setDeletingMeetingId(meeting.id)}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 flex flex-col items-center text-center">
                  <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No upcoming meetings</h3>
                  <p className="text-gray-500 mb-6">You don't have any scheduled meetings coming up.</p>
                  <Button className="bg-[#1C4A1C] hover:bg-[#2C602C]" onClick={() => setCreateDialogOpen(true)}>
                    Schedule Your First Meeting
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="past">
            {pastMeetings.length > 0 ? (
              <div className="space-y-4">
                {pastMeetings.map((meeting) => (
                  <MeetingCard 
                    key={meeting.id} 
                    meeting={meeting} 
                    isPast
                    onDelete={() => setDeletingMeetingId(meeting.id)}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 flex flex-col items-center text-center">
                  <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No past meetings</h3>
                  <p className="text-gray-500">Your meeting history will appear here.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Delete confirmation dialog */}
      <AlertDialog 
        open={deletingMeetingId !== null}
        onOpenChange={(open) => !open && setDeletingMeetingId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this meeting and notify all participants. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-red-600 hover:bg-red-700"
              onClick={() => deletingMeetingId && deleteMeetingMutation.mutate(deletingMeetingId)}
              disabled={deleteMeetingMutation.isPending}
            >
              {deleteMeetingMutation.isPending ? "Deleting..." : "Delete Meeting"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface MeetingCardProps {
  meeting: Meeting;
  isPast?: boolean;
  onDelete: () => void;
}

function MeetingCard({ meeting, isPast, onDelete }: MeetingCardProps) {
  const startDate = new Date(meeting.startTime);
  const endDate = new Date(meeting.endTime);
  
  const attendeesCount = Array.isArray(meeting.attendees) ? meeting.attendees.length : 0;
  
  return (
    <Card className="hover:shadow-md transition-shadow">
      <div className="p-4 sm:p-6 flex flex-col sm:flex-row gap-4">
        <div className="sm:w-1/4">
          <div className="bg-[#1C4A1C]/10 text-[#1C4A1C] p-3 rounded-md inline-block">
            <Calendar className="h-5 w-5" />
          </div>
          <h3 className="font-semibold mt-2">{meeting.title}</h3>
          <p className="text-sm text-gray-500">ID: {meeting.id}</p>
        </div>
        
        <div className="flex-1 space-y-2">
          <div className="flex items-center text-sm text-gray-600">
            <Clock className="h-4 w-4 mr-2" />
            <span>{formatDate(startDate, "EEE, MMM d, yyyy")}</span>
            <span className="mx-2">•</span>
            <span>{formatTime(startDate)} - {formatTime(endDate)}</span>
            <span className="mx-2">•</span>
            <span>{meeting.timezone}</span>
          </div>
          
          {meeting.location && (
            <div className="flex items-center text-sm text-gray-600">
              <Video className="h-4 w-4 mr-2" />
              <span>{meeting.location}</span>
            </div>
          )}
          
          <div className="flex items-center text-sm text-gray-600">
            <Users className="h-4 w-4 mr-2" />
            <span>{attendeesCount} attendee{attendeesCount !== 1 ? 's' : ''}</span>
          </div>
        </div>
        
        <div className="flex sm:flex-col gap-2 justify-end">
          {!isPast && (
            <Button 
              variant="outline" 
              className="text-[#1C4A1C] border-[#1C4A1C]"
              onClick={() => {}}
            >
              <Video className="h-4 w-4 mr-2" />
              Join
            </Button>
          )}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon"
                className="text-red-500 hover:text-red-600 hover:bg-red-50"
              >
                <Trash className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete this meeting and notify all participants.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  className="bg-red-600 hover:bg-red-700"
                  onClick={onDelete}
                >
                  Delete Meeting
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </Card>
  );
}
